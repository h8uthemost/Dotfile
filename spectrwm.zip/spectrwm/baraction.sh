#!/bin/bash
# baraction.sh script for spectrwm status bar

## Kernel
kernel() {
    kernel=`uname -r`
    echo -e "  $kernel"
}

## DISK
trap 'update' 5

mpd(){
	song="$(mpc current)"
	status="$(mpc status | grep paused | awk '{print $1}')"
	echo -e " $song"
}
hdd() {
	hdd="$(df -h /home | grep /dev | awk '{print $3 "/" $2}')"
	    echo -e " $hdd"
}

## RAM
mem() {
  mem=`free | awk '/Mem/ {printf "%dM/%dM\n", $3 / 1024.0, $2 /1024.0 }'`
  echo -e "  $mem"
}

## CPU
cpu() {
  read cpu a b c previdle rest < /proc/stat
  prevtotal=$((a+b+c+previdle))
  sleep 0.5
  read cpu a b c idle rest < /proc/stat
  total=$((a+b+c+idle))
  cpu=$((100*( (total-prevtotal) - (idle-previdle) ) / (total-prevtotal) ))
  echo -e "  $cpu%"
}

## WiFi
WiFi() {
	ssid=$(nmcli -t -f active,ssid dev wifi | egrep '^yes' | cut -d\: -f2)
        if [ -z $ssid ]; then ssid="None"; fi
	echo "  $ssid"
}

## Volume
vol() {
	vol=`pulsemixer --get-volume | awk '{print ($1 + $2) / 2}'`
    echo -e " $vol%"
}

## Battery
bat() {
batstat="$(cat /sys/class/power_supply/BAT0/status)"
battery="$(cat /sys/class/power_supply/BAT0/capacity)"
    if [ $batstat = 'Unknown' ]; then
    batstat=""
    elif [[ $battery -ge 5 ]] && [[ $battery -le 19 ]]; then
    batstat=""
    elif [[ $battery -ge 20 ]] && [[ $battery -le 39 ]]; then
    batstat=""
    elif [[ $battery -ge 40 ]] && [[ $battery -le 59 ]]; then
    batstat=""
    elif [[ $battery -ge 60 ]] && [[ $battery -le 79 ]]; then
    batstat=""
    elif [[ $battery -ge 80 ]] && [[ $battery -le 95 ]]; then
    batstat=""
    elif [[ $battery -ge 96 ]] && [[ $battery -le 100 ]]; then
    batstat=""
fi

echo "$batstat  $battery"
}

## Packages
pkgs() {
	pkgs="$(xbps-query -l | wc -l)"
	echo -e " $pkgs"
}

## Upgrades
upgrades() {
	upgrades="$(xbps-install -Mun | wc -l)"
	echo -e "↑ $upgrades"
}

SLEEP_SEC=3
#loops forever outputting a line every SLEEP_SEC secs

# It seems that we are limited to how many characters can be displayed via
# the baraction script output. And the the markup tags count in that limit.
# So I would love to add more functions to this script but it makes the 
# echo output too long to display correctly.
while :; do
    echo "$(mpd) | $(kernel) | $(pkgs) | $(upgrades) | $(WiFi) | $(vol) | $(bat) |"
	sleep $SLEEP_SEC
done

